<?php
// p360/includes/footer.php
?>
<footer style="background: var(--color-light); color: var(--color-muted); text-align:center; padding:1rem; font-size:0.9rem;">
  &copy; <?= date('Y') ?> Pinturas Grupo FERRO. Todos los derechos reservados.
</footer>
