<?php
echo password_hash('fernandez', PASSWORD_DEFAULT);
